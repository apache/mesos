Moved to [wait-for-ready.md](wait-for-ready.md)
