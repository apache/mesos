#ifndef JEMALLOC_INTERNAL_BASE_TYPES_H
#define JEMALLOC_INTERNAL_BASE_TYPES_H

typedef struct base_block_s base_block_t;
typedef struct base_s base_t;

#endif /* JEMALLOC_INTERNAL_BASE_TYPES_H */
